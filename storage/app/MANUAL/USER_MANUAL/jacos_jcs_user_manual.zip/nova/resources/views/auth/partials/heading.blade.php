<h2 class="text-2xl text-center font-normal mb-6 text-90">{{ $slot }}</h2>
<svg class="block mx-auto mb-6" xmlns="http://www.w3.org/2000/svg" width="100" height="2" viewBox="0 0 100 2">
  <path fill="#D8E3EC" d="M0 0h100v2H0z"/>
</svg>
